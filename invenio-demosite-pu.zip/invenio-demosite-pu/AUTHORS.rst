=========================
Invenio demo site authors
=========================

Authors and contributors: (active)

- Tibor Simko <tibor.simko@cern.ch>
- Jerome Caffaro <jerome.caffaro@cern.ch>
- Samuele Kaplun <samuele.kaplun@cern.ch>
- Ludmila Marian <ludmila.marian@gmail.com>
- Nikolaos Kasioumis <nikolaos.kasioumis@cern.ch>
- Javier Martin <javier.martin.montull@cern.ch>
- Roman Chyla <roman.chyla@cern.ch>
- Jan Aage Lavik <jan.age.lavik@cern.ch>
- Samuele Carli <samuele.carli@cern.ch>
- Jay Luker <lbjay@reallywow.com>
- Patrick Glauner <patrick.oliver.glauner@cern.ch>
- Alessio Deiana <alessio.deiana@cern.ch>
- Esteban J. G. Gabancho <esteban.jose.garcia.gabancho@cern.ch>
- Jiri Kuncar <jiri.kuncar@cern.ch>
- Laura Rueda <laura.rueda@cern.ch>
- Lars Holm Nielsen <lars.holm.nielsen@cern.ch>
- Sebastian Witowski <sebastian.witowski@cern.ch>
- Wojciech Ziolek <wojciech.ziolek@cern.ch>
- Grzegorz Szpura <grzegorz.szpura@cern.ch>
- Graham R. Armstrong <graham.richard.armstrong@cern.ch>
- Kirsten Sachs <kirsten.sachs@cern.ch>
- Nikolaos Kalodimas <nikolaos.kalodimas@cern.ch>
- Adrian Tudor Panescu <adrian.tudor.panescu@cern.ch>
- Dinos Kousidis <konstantinos.kousidis@cern.ch>
- Guillaume Lastecoueres <guillaume.lastecoueres@cern.ch>

Authors and contributors: (former team members)

- Thomas Baron <thomas.baron@cern.ch>
- Trond Aksel Myklebust <trond.aksel.myklebust@cern.ch>
- Anna Afshar <anna.afsharghasemlouy@epfl.ch>
- Diane Berkovits <diane.berkovits@cern.ch>
- Martin Vesely <martin.vesely@cern.ch>
- Øyvind Østlund <oyvind.ostlund@cern.ch>
- Frederic Gobry <frederic.gobry@epfl.ch>
- Krzysztof Jedrzejek <krzysztof.jedrzejek@cern.ch>
- Nicholas Robinson <nicholas.robinson@cern.ch>
- Marko Niinimaki <manzikki@gmail.com>
- Tony Osborne <tony.osborne@cern.ch>
- Radoslav Ivanov <radoslav.ivanov@cern.ch>
- Ruben Pollan <ruben.pollan@cern.ch>
- Lars Christian Raae <lars.christian.raae@cern.ch>
- Joaquim Rodrigues Silvestre <joaquim.rodrigues.silvestre@cern.ch>
- Glenn Gard <glenng4@aol.com>
- Valkyrie Savage <vasavage@gmail.com>
- Pablo Vázquez Caderno <pcaderno@cern.ch>
- Mathieu Barras <mbarras@gmail.com>
- Christopher Dickinson <christopher.dickinson@cern.ch>
- Travis Brooks <travis@slac.stanford.edu>
- Björn Oltmanns <bjoern.oltmanns@gmail.com>
- Jan Iwaszkiewicz <jan.iwaszkiewicz@cern.ch>
- Juan Francisco Pereira Corral <juan.francisco.pereira.corral@cern.ch>
- Henning Weiler <henning.weiler@cern.ch>
- Carmen Alvarez Perez <carmen.alvarez.perez@cern.ch>
- Nikola Yolov <nikola.yolov@cern.ch>
- Benoit Thiell <benoit.thiell@cern.ch>
- Joe Blaylock <jrbl@slac.stanford.edu>
- Kevin M. Flannery <flannery@fnal.gov>
- Peter Halliday <phalliday@cornell.edu>
- Vasanth Venkatraman <vasanth.venkatraman@cern.ch>
- Daniel Stanculescu <daniel.stanculescu@cern.ch>
- Konstantinos Ntemagkos <konstantinos.ntemagkos@cern.ch>
- David Bengoa <david.bengoa.rocandio@cern.ch>
- Gerrit Rindermann <Gerrit.Rindermann@cern.ch>
- Markus Goetz <murxman@gmail.com>
- Yannick Tapparel <yannick.tapparel@cern.ch>
- Giovanni Di Milia <gdimilia@cfa.harvard.edu>
- Alper Cinar <alper@srdc.com.tr>
- Eduardo Benavidez <eduardo.benavidez@gmail.com>
- Krzysztof Lis <krzysztof.lis@cern.ch>
- Piotr Praczyk <piotr.praczyk@gmail.com>
- Raja Sripada <rsripada@cern.ch>
- Jaime Garcia Llopis <jaime.garcia.llopis@cern.ch>
- Raquel Jimenez Encinar <raquel.jimenez.encinar@cern.ch>


*Note: before 2014, Invenio demo site was being developed inside the
main Invenio source code package.  Please see the main Invenio source
code repository for more information.*

Good luck and thanks for choosing Invenio.

| Invenio Development Team
|   Email: info@invenio-software.org
|   IRC: #invenio on irc.freenode.net
|   Twitter: @inveniosoftware
|   URL: http://invenio-software.org
