=================
Invenio demo site
=================

This is Invenio demo site source code overlay.  It installs on top of
Invenio digital library platform source code.

The repository contains basic site configuration as well as example
demo records.  It permits one to build Invenio demo site and run
various acceptance/functional/regression testing.

Note that you can use this repository as a model to create your own
Invenio production service overlay.

*Note: before 2014, Invenio demo site was being developed inside the
main Invenio source code package.  Please see the main Invenio source
code repository for more information.*

Good luck and thanks for choosing Invenio.

| Invenio Development Team
|   Email: info@invenio-software.org
|   IRC: #invenio on irc.freenode.net
|   Twitter: @inveniosoftware
|   URL: http://invenio-software.org
