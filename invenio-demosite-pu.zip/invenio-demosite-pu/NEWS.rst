======================
Invenio demo site news
======================

Here is a short summary of the most notable changes in Invenio demo
site releases.

*Note: before 2014, Invenio demo site was being developed inside the
main Invenio source code package.  Please see the main Invenio source
code repository for more information.*

Good luck and thanks for choosing Invenio.

| Invenio Development Team
|   Email: info@invenio-software.org
|   IRC: #invenio on irc.freenode.net
|   Twitter: @inveniosoftware
|   URL: http://invenio-software.org
